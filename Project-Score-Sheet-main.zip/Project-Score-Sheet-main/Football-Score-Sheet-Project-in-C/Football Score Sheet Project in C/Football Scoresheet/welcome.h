void welcome()
{
                system("color f1");
                int i,y;
                locate(27,5);
                printf("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _");
                locate(27,7);
                  printf("*******************************");
                  locate(27,9);
                  printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3);
            	locate(27,11);
                  printf(" %c%c%c!!! YOU ARE WELCOME !!!%c%c%c",2,2,2,2,2,2);
                  locate(40,13);
                  printf("TO");
                  locate(27,15);
                  printf(" %c%c%c Football score sheet %c%c%c",3,3,3,3,3,3);
                  locate(27,17);
                  printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3);
                  locate(27,19);
                  printf("*******************************");
                  locate(27,20);
                  printf("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _");
                  Sleep(750);
                  locate(26,23);
                  printf(" @Copy righted to:-Alish Tuladhar & Nayan Banskota");
                  Sleep(1000);
                  locate(39,25);
                  printf("ENJOY %c%c",3,2);
                  Sleep(1500);
                  locate(28,25);
                  SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_GREEN | FOREGROUND_INTENSITY | FOREGROUND_BLUE );
                  SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_GREEN | FOREGROUND_INTENSITY | FOREGROUND_BLUE );
				system("color ff");
}





